## PHP-MySQL-CRUD

> PHP-MySQL CRUD operations using MySQLi (Procedural style).

### Project Demo

Live Project URL- [PHP-MySQL-CRUD](https://live-demo2.000webhostapp.com/)

### Screenshots

![screenshot](screenshots/read-1.png)
![screenshot](screenshots/read-2.png)
![screenshot](screenshots/create-1.png)
![screenshot](screenshots/create-2.png)
![screenshot](screenshots/update.png)
